
test - v2 2
==============================

This dataset was exported via roboflow.ai on October 9, 2020 at 8:27 AM GMT

It includes 22 images.
Hole-bracket-welding-bolt are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)
* Auto-contrast via adaptive equalization

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -5 and +5 degrees


